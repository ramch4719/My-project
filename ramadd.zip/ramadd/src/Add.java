import java.io.*;
public class Add {

	public static void main(String[] args) throws NumberFormatException, IOException 
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try
		{
		int  a=Integer.parseInt(br.readLine());
		int b=Integer.parseInt(br.readLine());
		Add q=new Add();
		int y=q.add(a, b);
		System.out.println(y);
		}
		catch(NumberFormatException e)
		{
			System.out.println("Invalid Input");
		}
	}
	
	int add(int a1,int b1)
	{
		int c=a1+b1;
		return c;
	}

}
