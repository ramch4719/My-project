package com.javatpoint;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Check {
	public boolean checkp(String s)
	{   
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost:3306/bank","root","root"); 
		Statement gmt=con.createStatement();
		String selectQuery="select * from bankso where loanAccountNumber='"+s+"'" ;
		ResultSet rs=gmt.executeQuery(selectQuery);
		if(rs.next())
		{
			return true;
		}
		else
			return false;
		}
		catch(Exception e)
		{
			System.out.println(e);
            return false;
		}
	}
	public boolean checkq(String s)
	{   
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost:3306/bank","root","root"); 
		Statement gmt=con.createStatement();
		String selectQuery="select * from bankso where customerId='"+s+"'";
		ResultSet rs=gmt.executeQuery(selectQuery);
		if(rs.next())
		{
			return true;
		}
		else
			return false;
		}
		catch(Exception e)
		{
			System.out.println(e);
            return false;
		}
	}
	public boolean checkr(String s)
	{   
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost:3306/bank","root","root"); 
		Statement gmt=con.createStatement();
		String selectQuery="select * from bankso where installmentAmount='"+s+"'";
		ResultSet rs=gmt.executeQuery(selectQuery);
		if(rs.next())
		{
			return true;
		}
		else
			return false;
		}
		catch(Exception e)
		{
			System.out.println(e);
            return false;
		}
	}
	public boolean checks(String s)
	{   
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost:3306/bank","root","root"); 
		Statement gmt=con.createStatement();
		String selectQuery="select * from bankso where totalInstallments='"+s+"'";
		ResultSet rs=gmt.executeQuery(selectQuery);
		if(rs.next())
		{
			return true;
		}
		else
			return false;
		}
		catch(Exception e)
		{
			System.out.println(e);
            return false;
		}
	}
	public boolean checkt(String s)
	{   
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost:3306/bank","root","root"); 
		Statement gmt=con.createStatement();
		String selectQuery="select * from bankso where installmentspaid='"+s+"'";
		ResultSet rs=gmt.executeQuery(selectQuery);
		if(rs.next())
		{
			return true;
		}
		else
			return false;
		}
		catch(Exception e)
		{
			System.out.println(e);
            return false;
		}
	}
    
 }
