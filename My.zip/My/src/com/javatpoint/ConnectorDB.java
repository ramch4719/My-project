package com.javatpoint;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectorDB {
	public void establishConnection(UserDetails sm) throws ClassNotFoundException
	{   
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(  
					"jdbc:mysql://localhost:3306/bank","root","root"); 
			Statement gmt=con.createStatement();
			String selectQuery="select * from bankso where loanAccountNumber='"+sm.getLoanAccountNumber()+"'and customerId='"+sm.getCustomerId()+"' and installmentAmount='"+sm.getInstallmentAmount()+"' and totalInstallments='"+sm.getTotalInstallments()+"' and installmentspaid='"+sm.getInstallmentspaid()+"'";
			ResultSet rs=gmt.executeQuery(selectQuery);
			if(rs.next())
			{
				System.out.println("These records already found");
			}
			else
			{
		PreparedStatement stmt=con.prepareStatement("insert into bankso values(?,?,?,?,?);");
		stmt.setString(1,sm.getLoanAccountNumber());
		stmt.setString(2,sm.getCustomerId());
		stmt.setString(3,sm.getInstallmentAmount());
		stmt.setString(4,sm.getTotalInstallments());
		stmt.setString(5,sm.getInstallmentspaid());
		int o=stmt.executeUpdate();  
		System.out.println(o+" records affected");  
			}
					con.close();  
		}
		catch(Exception e)
		{
			System.out.println("connection not established");
		}
		
	}

}
