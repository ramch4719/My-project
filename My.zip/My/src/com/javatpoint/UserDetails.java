package com.javatpoint;
public class UserDetails {
	private String loanAccountNumber;
	private String customerId;
	private String installmentAmount;
	private String totalInstallments;
	private String installmentspaid;
	public String getLoanAccountNumber() {
		return loanAccountNumber;
	}
	public void setLoanAccountNumber(String loanAccountNumber) {
		this.loanAccountNumber = loanAccountNumber;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getInstallmentAmount() {
		return installmentAmount;
	}
	public void setInstallmentAmount(String installmentAmount) {
		this.installmentAmount = installmentAmount;
	}
	public String getTotalInstallments() {
		return totalInstallments;
	}
	public void setTotalInstallments(String totalInstallments) {
		this.totalInstallments = totalInstallments;
	}
	public String getInstallmentspaid() {
		return installmentspaid;
	}
	public void setInstallmentspaid(String installmentspaid) {
		this.installmentspaid = installmentspaid;
	}
	public UserDetails(String loanAccountNumber, String customerId, String installmentAmount, String totalInstallments,
			String installmentspaid) {
		super();
		this.loanAccountNumber = loanAccountNumber;
		this.customerId = customerId;
		this.installmentAmount = installmentAmount;
		this.totalInstallments = totalInstallments;
		this.installmentspaid = installmentspaid;
	}
	public UserDetails() {
		// TODO Auto-generated constructor stub
	}
	
	
	

}
