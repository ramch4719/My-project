package com.javatpoint;  
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
public class DataStreamExample{
public static void main(String[] args)throws Exception 
{ 
// We need to provide file path as the parameter: 
// double backquote is to avoid compiler interpret words 
// like \test as \t (ie. as a escape sequence) 
	 BufferedReader reader = new BufferedReader(new FileReader(
             "testout.txt"));
       
     // Read lines from file.
	 UserDetails[] ud=new UserDetails[100];
       int i=0;
       ConnectorDB db = new ConnectorDB();
     while (true) {
         String line = reader.readLine();
         if (line == null) {
             break;
         }
         // Split line on comma.
         String[] parts = line.split(Pattern.quote("|"));
          ud[i]=new UserDetails(parts[0],parts[1],parts[2],parts[3],parts[4]);
         for (String part : parts) {
             System.out.println(part);
         }
         db.establishConnection(ud[i]);
         i++;
         System.out.println();
     }
   
    	
     reader.close();
      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
      System.out.println("Enter the string to be searched:");
      String e=br.readLine();
      Check cy=new Check();
      if(cy.checkp(e)==true)
      {
    	  System.out.println("it is found in loan account number");
      }
      else if(cy.checkq(e)==true)
      {
    	  System.out.println("it is found in customer id");
      }
      else if(cy.checkr(e)==true)
      {
    	  System.out.println("it is found in installment amount");
      }
      else if(cy.checks(e)==true)
      {
    	  System.out.println("it is found in total instalments");
      }
      else if(cy.checkt(e)==true)
      {
    	  System.out.println("it is found in installments paid");
      }
      else
      {
    	  System.out.println("There is no such records");
      }
    

} 

}