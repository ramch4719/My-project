
public class Bank {
	public Bank(int accountNo, int password) {
		super();
		this.accountNo = accountNo;
		this.password = password;
	}
	private int accountNo;
	private int password;
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	
}
