import java.io.*;
public class Main {

	public static void main(String[] args)throws NumberFormatException, IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int a=Integer.parseInt(br.readLine());
		int b=Integer.parseInt(br.readLine());
		Bank b1=new Bank(a,b);
		String m=String.valueOf(b1.getAccountNo());
		String n=String.valueOf(b1.getPassword());
		if(m.equalsIgnoreCase("7545511")&&n.equalsIgnoreCase("4741"))
		{
			System.out.println("valid users");
		}
		else
		{
			System.out.println("Invalid users");
		}

	}

}
