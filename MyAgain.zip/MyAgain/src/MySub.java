import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class MySub {


	public static void main(String[] args)throws Exception {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		String q=new String();
		do
		{
		String s=br.readLine();
		StringBuffer m=new StringBuffer(s);
	    m.reverse();
	    String a=String.valueOf(m);
		System.out.println(a);
		if(s.equals(a))
		{
			System.out.println("pallindrome");
		}
		else
		{
			System.out.println("not a pallindrome");
		}
        char [] l =new char[a.length()];
        String h=new String();
        for(int i=0;i<a.length();i++)
        {
        	l[i]=a.charAt(i);
        	if(l[i]!='a')
        	{
        		h=h+String.valueOf(l[i]);
        		try
        		{
        			Class.forName("com.mysql.jdbc.Driver");
        			Connection con=DriverManager.getConnection(  
        					"jdbc:mysql://localhost:3306/ram","root","root");  
        			PreparedStatement stmt =con.prepareStatement("insert into ram values(?,?);");
        			stmt.setString(1,"rams");
        			stmt.setString(2,"zxjm");
        			int o=stmt.executeUpdate();  
        			System.out.println(o+" records affected");  
        						con.close();  
        						}catch(Exception e){ System.out.println(e);}  
        						 
        		}
        	}
        
        System.out.println(h);
        System.out.println("Do you have to continue?(yes/no)");
		 q=br.readLine();
	}while(q.equalsIgnoreCase("yes"));
	}

}
