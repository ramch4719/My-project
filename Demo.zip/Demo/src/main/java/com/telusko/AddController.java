package com.telusko;

import java.lang.annotation.Annotation;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractUrlViewController;


@Controller
public class AddController {
	
	
	
	@RequestMapping("add")
	
	public String add(@RequestParam("t1") int z,@RequestParam("t2") int x,Model m)
	{
		int y=z+x;
		
	   m.addAttribute("result",y);
       return "result";
		
	}
	
	@RequestMapping("sub")
	
		public String sub(@RequestParam("t1") int p,@RequestParam("t2") int q,Model m)
		{
			int r=p-q;
			m.addAttribute("subtru",r);
			return "subtract";
		}
	}

	
	

