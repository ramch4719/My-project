package com.ram;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class DivController {
	
	
	
	@RequestMapping("div")
	
	public String add(@RequestParam("t1") int z,@RequestParam("t2") int x,Model m)
	{
		int y=z/x;
		
	   m.addAttribute("result",y);
       return "result";
		
	}
}